# 🕶️ blackhat-archives

> “Na escuridão dos logs e sob a chuva ácida dos pacotes, eu coleto, enumero, exploro e escalo.”

Repositório-vitrine dos meus estudos em **segurança ofensiva**. Cada diretório guarda rituais digitais — scripts, provas de conceito e anotações de ataques conduzidos em ambientes controlados.

---

## 📁 Diretórios

- `exploits/`: Códigos e PoCs de falhas exploradas em ambientes de laboratório.
- `enum/`: Scripts de enumeração para redes, DNS, serviços e portas.
- `osint/`: Coleta de informações públicas — footprints, WHOIS, redes sociais.
- `wifi-attacks/`: Ferramentas e dumps de ataques contra WEP/WPA2.
- `steganography/`: Mensagens ocultas, análise de arquivos com esteganálise.
- `keyloggers/`: Keyloggers e análise comportamental de captura de teclado.
- `macos-pentest/`: Notas sobre exploração de ambientes macOS.
- `ai-offensive/`: Uso de LLMs em tarefas ofensivas e engenharia social automatizada.
- `tools/`: Ferramentas customizadas, aliases e helpers pessoais.

---

## 📜 Aviso

Este repositório é **educacional**. Todo o conteúdo é voltado para testes em ambientes autorizados. Use com ética — ou que os IDSs te condenem.

“**A rede respira. Eu escuto.**”
